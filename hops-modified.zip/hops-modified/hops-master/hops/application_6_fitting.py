
import os
import glob
import numpy as np
import shutil
import exoclock
from tkinter.filedialog import askopenfilename
import matplotlib.image as mpimg
import matplotlib.gridspec as gridspec
import hops.pylightcurve41 as plc

from matplotlib.figure import Figure
from matplotlib.backend_bases import MouseEvent as mpl_MouseEvent

from hops.application_windows import MainWindow, AddOnWindow

filter_map = {'Clear': 'clear',
              'Luminance': 'luminance',
              'U': 'JOHNSON_U',
              'B': 'JOHNSON_B',
              'V': 'JOHNSON_V',
              'R': 'COUSINS_R',
              'I': 'COUSINS_I',
              'Gaia G': 'GAIA_G',
              'Gaia BP': 'GAIA_BP',
              'Gaia RP': 'GAIA_RP',
              'H': '2mass_h',
              'J': '2mass_j',
              'K': '2mass_ks',
              'Astrodon ExoPlanet-BB': 'exoplanets_bb',
              'u\'': 'sdss_u',
              'g\'': 'sdss_g',
              'r\'': 'sdss_r',
              'z\'': 'sdss_z',
              }


gaia_ld_fallback = {
    'Gaia G': 'JOHNSON_V',
    'Gaia BP': 'JOHNSON_B',
    'Gaia RP': 'COUSINS_R',
}

__location__ = os.path.abspath(os.path.dirname(__file__))


class FittingWindow(MainWindow):

    def __init__(self, log):

        # define windows

        MainWindow.__init__(self, log, name='HOPS - Fitting', position=2)
        self.export_window = AddOnWindow(self, name='Export Results', position=1)

        # data

        self.all_frames = plc.open_dict(self.log.all_frames)
        self.science_files = []
        self.exposure_time = []
        for science_file in self.all_frames:
            if not self.all_frames[science_file][self.log.skip_key]:
                self.science_files.append([science_file, self.all_frames[science_file][self.log.time_key]])
                self.exposure_time.append(self.all_frames[science_file][self.log.get_param('exposure_time_key')])

        self.exposure_time = np.median(self.exposure_time)

        # exclusions clic (préparation courbe pour transit_fitting) ; indices = rangées du fichier PHOTOMETRY
        self.fitting_excluded_indices = set()
        self.fitting_exclusion_stack = []
        self._lc_exclusion_source_path = None
        self._last_planet = None
        self._last_fitting = None
        self._last_plot_lc_type = 'Raw'
        self._orig_indices_active = None
        self._pick_orig_index_map = None
        self._pickable_ax1_line = None
        self._pickable_ax2_line = None

        # main window

        photometry_files = (glob.glob(os.path.join('{0}*'.format(self.log.photometry_directory_base), self.log.light_curve_aperture_file)) +
                            glob.glob(os.path.join('{0}*'.format(self.log.photometry_directory_base), self.log.light_curve_gauss_file)))
        photometry_files_sort = []
        for ff in photometry_files:
            folder = os.path.split(ff)[0]
            if '_' not in folder:
                num = 1
            else:
                num = int(folder.split('_')[1])
            
            photometry_files_sort.append([num, ff])
        
        photometry_files_sort.sort()
        
        photometry_files = [ff[1] for ff in photometry_files_sort]
        photometry_files = ['Choose Light-curve file'] + photometry_files

        if self.log.get_param('light_curve_file') not in photometry_files:
            self.log.set_param('light_curve_file', 'Choose Light-curve file')
        
        self.light_curve_file = self.DropDown(initial=self.log.get_param('light_curve_file'),
                                              instance=str,
                                              options=photometry_files,
                                              width=40, command=self.update_lc)

        self.iterations = self.Entry(value=self.log.get_param('iterations'), instance=int)
        self.burn = self.Entry(value=self.log.get_param('burn'), instance=int)
        self.a_i_fit = self.CheckButton(initial=self.log.get_param('a_i_fit'), text='Fit for a/Rs, i.',
                                        command=self.update_planet)
        self.detrending = self.DropDown(initial=self.log.get_param('detrending'),
                                        options=['Airmass', 'Quadratic', 'Linear'],
                                        instance=str, command=self.update_planet)
        self.manual_planet = self.CheckButton(initial=self.log.get_param('manual_planet'),
                                              text='Enter param. manually', command=self.update_planet)

        self.planet = self.Entry(value=self.log.get_param('planet'), command=self.update_planet)
        self.target_ra_dec = self.Entry(value=self.log.get_param('target_ra_dec'), command=self.update_planet)
        self.metallicity = self.Entry(value=self.log.get_param('metallicity'), instance=float, command=self.update_planet)
        self.temperature = self.Entry(value=self.log.get_param('temperature'), instance=float, command=self.update_planet)
        self.logg = self.Entry(value=self.log.get_param('logg'), instance=float, command=self.update_planet)
        self.period = self.Entry(value=self.log.get_param('period'), instance=float, command=self.update_planet)
        self.mid_time = self.Entry(value=self.log.get_param('mid_time'), instance=float, command=self.update_planet)
        self.rp_over_rs = self.Entry(value=self.log.get_param('rp_over_rs'), instance=float, command=self.update_planet)
        self.sma_over_rs = self.Entry(value=self.log.get_param('sma_over_rs'), instance=float, command=self.update_planet)
        self.inclination = self.Entry(value=self.log.get_param('inclination'), instance=float, command=self.update_planet)
        self.eccentricity = self.Entry(value=self.log.get_param('eccentricity'), instance=float, command=self.update_planet)
        self.periastron = self.Entry(value=self.log.get_param('periastron'), instance=float, command=self.update_planet)

        try:
            ra_target, dec_target = self.log.get_param('target_ra_dec').split(' ')
            ecc_data = exoclock.locate_planet(exoclock.Hours(ra_target), exoclock.Degrees(dec_target))
            self.auto_planet = self.Label(text=ecc_data['name'])
            self.auto_target_ra_dec = self.Label(text='{0} {1}'.format(ecc_data['star']['ra'], ecc_data['star']['dec']))
            self.auto_metallicity = self.Label(text=ecc_data['planet']['meta'], instance=float)
            self.auto_temperature = self.Label(text=ecc_data['planet']['teff'], instance=float)
            self.auto_logg = self.Label(text=ecc_data['planet']['logg'], instance=float)
            self.auto_period = self.Label(text=ecc_data['planet']['ephem_period'], instance=float)
            self.auto_mid_time = self.Label(text=ecc_data['planet']['ephem_mid_time'], instance=float)
            self.auto_rp_over_rs = self.Label(text=ecc_data['planet']['rp_over_rs'], instance=float)
            self.auto_sma_over_rs = self.Label(text=ecc_data['planet']['sma_over_rs'], instance=float)
            self.auto_eccentricity = self.Label(text=ecc_data['planet']['eccentricity'], instance=float)
            self.auto_inclination = self.Label(text=ecc_data['planet']['inclination'], instance=float)
            self.auto_periastron = self.Label(text=ecc_data['planet']['periastron'], instance=float)
        except:
            planet = None
            self.auto_planet = self.Label(text='None')
            self.auto_target_ra_dec = self.Label(text='None')
            self.auto_metallicity = self.Label(text=0, instance=float)
            self.auto_temperature = self.Label(text=0, instance=float)
            self.auto_logg = self.Label(text=0, instance=float)
            self.auto_period = self.Label(text=0, instance=float)
            self.auto_mid_time = self.Label(text=0, instance=float)
            self.auto_rp_over_rs = self.Label(text=0, instance=float)
            self.auto_sma_over_rs = self.Label(text=0, instance=float)
            self.auto_eccentricity = self.Label(text=0, instance=float)
            self.auto_inclination = self.Label(text=0, instance=float)
            self.auto_periastron = self.Label(text=0, instance=float)

        if self.planet.get() == 'Choose Planet':
            self.planet.set(self.auto_planet.get())
            self.target_ra_dec.set(self.auto_target_ra_dec.get())
            self.metallicity.set(self.auto_metallicity.get())
            self.temperature.set(self.auto_temperature.get())
            self.logg.set(self.auto_logg.get())
            self.period.set(self.auto_period.get())
            self.mid_time.set(self.auto_mid_time.get())
            self.rp_over_rs.set(self.auto_rp_over_rs.get())
            self.sma_over_rs.set(self.auto_sma_over_rs.get())
            self.inclination.set(self.auto_inclination.get())
            self.eccentricity.set(self.auto_eccentricity.get())
            self.periastron.set(self.auto_periastron.get())

        # set progress variables, useful for updating the window

        self.test_button = self.Button(text='RUN TEST', command=[self.disable, self.run_test],
                                          bg='green', highlightbackground='green')
        self.fitting_button = self.Button(text='RUN FITTING',
                                          command=[self.disable, self.save_settings, self.run_fitting, self.activate],
                                          bg='green', highlightbackground='green')

        self.export_button = self.Button(text='EXPORT FOR DATABASES (ExoClock / ETD / AAVSO)', command=self.export_window.show)

        # define preview window

        funit = 0.8
        fcol = 7
        frow = 5
        fbottom = 0.11
        fright = 0.02
        self.fssmall = 7
        self.fsmain = 9
        self.fsbig = 20
        self.preview_figure = self.FigureWindow(figsize=(6, 7), show_nav=True)
        self.preview_figure.figure.canvas.callbacks.connect('button_press_event', self.show_point_info)
        self.preview_figure.figure.canvas.mpl_connect('pick_event', self._on_lc_pick)
        try:
            gs = gridspec.GridSpec(frow, fcol, self.preview_figure.figure, 0.03, fbottom, 1.0 - fright, 1.0, 0.0, 0.0)
        except TypeError:
            gs = gridspec.GridSpec(frow, fcol, 0.03, fbottom, 1.0 - fright, 1.0, 0.0, 0.0)

        logo_ax = self.preview_figure.figure.add_subplot(gs[0, 0])
        logo_ax.imshow(mpimg.imread(self.log.files['holomon_logo']))
        logo_ax.spines['top'].set_visible(False)
        logo_ax.spines['bottom'].set_visible(False)
        logo_ax.spines['left'].set_visible(False)
        logo_ax.spines['right'].set_visible(False)
        logo_ax.tick_params(left=False, bottom=False, labelleft=False, labelbottom=False)

        self.ax1 = self.preview_figure.figure.add_subplot(gs[1:4, 1:])
        self.ax2 = self.preview_figure.figure.add_subplot(gs[4, 1:])
        self.preview_figure.figure.text(0.04, fbottom + 2.5 * (1 - fbottom) / frow, 'Relative flux (norm)', fontsize=self.fsmain, va='center',
                 ha='center', rotation='vertical')
        self.preview_figure.figure.text(0.04, fbottom + 0.5 * (1 - fbottom) / frow, 'Residuals (norm)', fontsize=self.fsmain, va='center',
                 ha='center', rotation='vertical')

        self.title1 = self.preview_figure.figure.text(0.5, 0.94, '', fontsize=self.fsbig, va='center', ha='center')
        self.title2 = self.preview_figure.figure.text(0.97, 0.97, '', fontsize=self.fsmain, va='top', ha='right')
        self.title3 = self.preview_figure.figure.text(0.03 + (1 - fright) / fcol, 1 - (1 - fbottom) / frow, '', fontsize=self.fsmain, ha='left', va='bottom')
        self.dblclick = False

        self.setup_window([
            [[self.preview_figure, 0, 1, 24]],
            [[self.Label(
                text='Left-click a point on the light curve or residuals to exclude it from fitting '
                     '(at least 6 points must remain).\n'
                     'Right-click inside either plot panel to undo the last exclusion.\n'
                     'After RUN TEST, the plot refreshes immediately and curve_fit is re-run on the remaining points.\n'
                     'Changing the light-curve file clears all exclusions and the undo history.'), 1, 3]],
            [[self.Label(text='Light-curve file'), 1, 3]],
            [[self.light_curve_file, 1, 3]],
            [[self.export_button, 1, 3]],
            [],
            [[self.Label(text='Catalogue param.'), 2], [self.manual_planet, 3]],

            [[self.Label(text='Planet'), 1], [self.auto_planet, 2], [self.planet, 3]],

            [[self.Label(text='Planet RA DEC\n(hh:mm:ss +/-dd:mm:ss)'), 1], [self.auto_target_ra_dec, 2], [self.target_ra_dec, 3]],

            [[self.Label(text='Period [days]'), 1], [self.auto_period, 2], [self.period, 3]],

            [[self.Label(text='Mid-time [BJD_TDB]'), 1], [self.auto_mid_time, 2], [self.mid_time, 3]],

            [[self.Label(text='Rp/Rs'), 1], [self.auto_rp_over_rs, 2], [self.rp_over_rs, 3]],

            [[self.Label(text='a/Rs'), 1], [self.auto_sma_over_rs, 2], [self.sma_over_rs, 3]],

            [[self.Label(text='Inclination [deg]'), 1], [self.auto_inclination, 2], [self.inclination, 3]],

            [[self.Label(text='Eccentricity'), 1], [self.auto_eccentricity, 2], [self.eccentricity, 3]],

            [[self.Label(text='Periastron [deg]'), 1], [self.auto_periastron, 2], [self.periastron, 3]],

            [[self.Label(text='M* [Fe/H, dex]'), 1], [self.auto_metallicity, 2], [self.metallicity, 3]],

            [[self.Label(text='T* [K]'), 1], [self.auto_temperature, 2], [self.temperature, 3]],

            [[self.Label(text='log(g*) [cm/s^2]'), 1], [self.auto_logg, 2], [self.logg, 3]],

            [[self.Label(text='MCMC options:'), 1, 2], [self.Label(text='De-trending:'), 3]],

            [[self.Label(text='Iterations (def=5000)'), 1], [self.iterations, 2], [self.detrending, 3]],
            [[self.Label(text='Burn-in (def=1000)'), 1], [self.burn, 2], [self.a_i_fit, 3]],

            [[self.Button(text='RETURN TO\nMAIN MENU', command=self.close), 1],
             [self.Button(text='SAVE OPTIONS &\nRETURN TO MAIN MENU', command=[self.save_settings, self.close]), 2],
             [self.Button(text='RETURN TO\nPHOTOMETRY', command=self.return_to_photometry), 3]
             ],
            [[self.test_button, 1],[self.fitting_button, 2]],
            [],

        ])

        self.update_lc()
        self.update_planet()

        # extra windows

        self.export_window_database = self.export_window.DropDown(initial='ExoClock', options=['ExoClock', 'ETD', 'AAVSO'],
                                                                  instance=str,
                                                                  command=self.export_window_update)
        self.export_window_camera_gain = self.export_window.Entry(value='1', instance=float)
        self.export_window_aavso_obscode = self.export_window.Entry(value='', instance=str)
        _aavso_dm = self.log.params.get('aavso_detrended_model_file', '') or ''
        self.export_window_aavso_detrended_path = self.export_window.Entry(
            value=_aavso_dm if _aavso_dm else ' ', instance=str)
        self.export_window_aavso_detrended_browse = self.export_window.Button(
            text='Browse…', command=self._browse_aavso_detrended)
        self.export_window_time_shift = 0
        self._export_format = 'exoclock'
        self.export_window_message = self.export_window.Label(text=' ')

        self.export_window.setup_window([
            [],
            [[self.export_window.Label(text='Database:'), 0]],
            [[self.export_window_database, 0]],
            [],
            [[self.export_window.Label(text='Camera gain (e-/ADU; ETD & AAVSO):'), 0]],
            [[self.export_window_camera_gain, 0]],
            [],
            [[self.export_window.Label(text='AAVSO OBSCODE (Observer ID, AAVSO only):'), 0]],
            [[self.export_window_aavso_obscode, 0]],
            [],
            [[self.export_window.Label(text='detrended_model.txt (AAVSO only):'), 0]],
            [[self.export_window_aavso_detrended_path, 0], [self.export_window_aavso_detrended_browse, 1]],
            [],
            [[self.export_window_message, 0]],
            [],
            [[self.export_window.Button(text='EXPORT', command=self.export), 0]],
            []
        ])

        self.export_window_update()

    _FITTING_LC_MIN_POINTS = 6

    def _load_lc_file_full(self):
        path = self.light_curve_file.get()
        if not path or path == 'Choose Light-curve file' or not os.path.isfile(path):
            return None
        lc = np.loadtxt(path, unpack=True)
        if isinstance(lc, np.ndarray):
            if lc.ndim == 1:
                return None
            lc = np.asarray(lc, dtype=float)
        else:
            lc = np.asarray(lc, dtype=float)
            if lc.ndim != 2 or lc.shape[0] < 3:
                return None
        lc[2] = np.abs(lc[2])
        return lc

    def _active_lc_from_full(self, lc_full):
        if lc_full is None:
            return None, None
        n = lc_full.shape[1]
        mask = np.ones(n, dtype=bool)
        for i in self.fitting_excluded_indices:
            ii = int(i)
            if 0 <= ii < n:
                mask[ii] = False
        if not np.any(mask):
            return None, None
        orig_map = np.nonzero(mask)[0]
        active = lc_full[:, mask]
        return active, orig_map

    def _register_pickable_errorbars(self, eb1, eb2):
        self._pickable_ax1_line = None
        self._pickable_ax2_line = None
        if eb1 is not None and len(eb1) > 0:
            eb1[0].set_picker(10)
            self._pickable_ax1_line = eb1[0]
        if eb2 is not None and len(eb2) > 0:
            eb2[0].set_picker(10)
            self._pickable_ax2_line = eb2[0]

    def _on_lc_pick(self, event):
        if event.mouseevent.button != 1:
            return
        if event.artist not in (self._pickable_ax1_line, self._pickable_ax2_line):
            return
        if event.artist is None:
            return
        if getattr(event, 'ind', None) is None or len(event.ind) == 0:
            return
        idx = int(event.ind[0])
        if self._pick_orig_index_map is None or idx < 0 or idx >= len(self._pick_orig_index_map):
            return
        orig = int(self._pick_orig_index_map[idx])
        lc_full = self._load_lc_file_full()
        if lc_full is None:
            return
        n = lc_full.shape[1]
        if orig < 0 or orig >= n:
            return
        if orig in self.fitting_excluded_indices:
            return
        if n - len(self.fitting_excluded_indices) <= self._FITTING_LC_MIN_POINTS:
            self.showinfo(
                'Fitting',
                'Cannot exclude more points: at least {0} must remain for fitting.'.format(
                    self._FITTING_LC_MIN_POINTS))
            return
        self.fitting_excluded_indices.add(orig)
        self.fitting_exclusion_stack.append(orig)
        self._refresh_after_point_exclusion()

    def _undo_last_point_exclusion(self):
        if not self.fitting_exclusion_stack:
            return
        last = self.fitting_exclusion_stack.pop()
        self.fitting_excluded_indices.discard(last)
        self._refresh_after_point_exclusion()

    def _refresh_after_point_exclusion(self):
        def work():
            if self._last_planet is not None and self._last_fitting is not None:
                try:
                    planet, fitting = self.call_plc_fitting(optimiser='curve_fit', output_folder=None)
                    self._last_planet = planet
                    self._last_fitting = fitting
                    self.plot_results_to_axes(
                        planet, fitting, self.ax1, self.ax2, self.title1, self.title2, self.title3,
                        self._last_plot_lc_type)
                except Exception as e:
                    self.log.runtime_exception('curve_fit after point exclusion', e)
                    self._last_planet = None
                    self._last_fitting = None
                    self._redraw_lc_preview_only()
                    self.showinfo('Fitting', 'Point excluded. Re-run RUN TEST after changing exclusions.\n{0}'.format(e))
            else:
                self._redraw_lc_preview_only()
            try:
                self.preview_figure.draw()
            except Exception:
                self.preview_figure.draw(update_level=2)

        self._call_in_hops_cwd(work)

    def _redraw_lc_preview_only(self):
        lc_full = self._load_lc_file_full()
        if lc_full is None:
            return
        packed = self._active_lc_from_full(lc_full)
        if packed[0] is None:
            return
        active, orig_map = packed
        self.ax1.cla()
        self.ax2.cla()
        eb1 = self.ax1.errorbar(active[0], active[1], active[2], c='k', fmt='o', ms=2, lw=0.5, zorder=0)
        self._pick_orig_index_map = orig_map
        self._register_pickable_errorbars(eb1, None)
        self.observation_date = exoclock.Moment(jd_utc=active[0][0]).utc().isoformat()[:16].replace('T', ' ')
        obs_duration = round(24 * (active[0][-1] - active[0][0]), 1)
        self.title2.set_text('{0} (UT)\nDur: {1}h / Exp: {2}s\nFilter: {3}'.format(
            self.observation_date, obs_duration, self.exposure_time, self.log.get_param('filter')))
        self.title3.set_text(
            '\n\n{0}\n{1}'.format(
                self.log.get_param('observer'), '{0} / {1} / {2}'.format(
                    self.log.get_param('observatory'), self.log.get_param('telescope'),
                    self.log.get_param('camera'))))

    def update_lc(self, *entry):

        if not entry:
            pass

        self.fitting_button.disable()

        path = self.light_curve_file.get()
        if path != self._lc_exclusion_source_path:
            self.fitting_excluded_indices = set()
            self.fitting_exclusion_stack = []
            self._lc_exclusion_source_path = path
            self._last_planet = None
            self._last_fitting = None

        if not os.path.isfile(self.light_curve_file.get()):

            self.fitting_excluded_indices = set()
            self.fitting_exclusion_stack = []

            self.export_button.disable()
            self.iterations.disable()
            self.burn.disable()
            self.a_i_fit.disable()
            self.detrending.disable()
            self.fitting_button.disable()
            self.test_button.disable()

            self.manual_planet.disable()
            self.target_ra_dec.disable()
            self.planet.disable()
            self.metallicity.disable()
            self.temperature.disable()
            self.logg.disable()
            self.period.disable()
            self.mid_time.disable()
            self.rp_over_rs.disable()
            self.sma_over_rs.disable()
            self.inclination.disable()
            self.eccentricity.disable()
            self.periastron.disable()

            self.ax1.cla()
            self.ax2.cla()
            self.title2.set_text('')
            self.title3.set_text('')

            self.preview_figure.draw(update_level=2)

        else:
            self.export_button.activate()
            self.iterations.activate()
            self.burn.activate()
            self.a_i_fit.activate()
            self.detrending.activate()
            self.test_button.activate()

            self.manual_planet.activate()
            if self.manual_planet.get():
                self.planet.activate()
                self.target_ra_dec.activate()
                self.metallicity.activate()
                self.temperature.activate()
                self.logg.activate()
                self.period.activate()
                self.mid_time.activate()
                self.rp_over_rs.activate()
                self.sma_over_rs.activate()
                self.inclination.activate()
                self.eccentricity.activate()
                self.periastron.activate()
            else:
                self.planet.disable()
                self.target_ra_dec.disable()
                self.metallicity.disable()
                self.temperature.disable()
                self.logg.disable()
                self.period.disable()
                self.mid_time.disable()
                self.rp_over_rs.disable()
                self.sma_over_rs.disable()
                self.eccentricity.disable()
                self.inclination.disable()
                self.periastron.disable()

            self._redraw_lc_preview_only()
            self.preview_figure.draw(update_level=2)

    def update_planet(self, *entry):

        if not entry:
            pass

        self.fitting_button.disable()

        if self.manual_planet.get():
            self.planet.activate()
            self.target_ra_dec.activate()
            self.metallicity.activate()
            self.temperature.activate()
            self.logg.activate()
            self.period.activate()
            self.mid_time.activate()
            self.rp_over_rs.activate()
            self.sma_over_rs.activate()
            self.eccentricity.activate()
            self.inclination.activate()
            self.periastron.activate()

            self.title1.set_text(r'{0}{1}{2}'.format(r'$\mathbf{', self.planet.get(), '}$'))

        else:
            self.planet.disable()
            self.target_ra_dec.disable()
            self.metallicity.disable()
            self.temperature.disable()
            self.logg.disable()
            self.period.disable()
            self.mid_time.disable()
            self.rp_over_rs.disable()
            self.sma_over_rs.disable()
            self.eccentricity.disable()
            self.inclination.disable()
            self.periastron.disable()

            self.title1.set_text(r'{0}{1}{2}'.format(r'$\mathbf{', self.auto_planet.get(), '}$'))

        self.preview_figure.draw()

    def run_test(self):
        try:
            planet, fitting = self.call_plc_fitting(optimiser='curve_fit')
            self._last_planet = planet
            self._last_fitting = fitting
            self._last_plot_lc_type = 'Raw'
            self.plot_results_to_axes(planet, fitting, self.ax1, self.ax2, self.title1, self.title2, self.title3, 'Raw')
            self.preview_figure.draw()
            self.activate()
            self.manual_planet.activate()
            if self.manual_planet.get():
                self.planet.activate()
                self.target_ra_dec.activate()
                self.metallicity.activate()
                self.temperature.activate()
                self.logg.activate()
                self.period.activate()
                self.mid_time.activate()
                self.rp_over_rs.activate()
                self.sma_over_rs.activate()
                self.inclination.activate()
                self.eccentricity.activate()
                self.periastron.activate()
            else:
                self.planet.disable()
                self.target_ra_dec.disable()
                self.metallicity.disable()
                self.temperature.disable()
                self.logg.disable()
                self.period.disable()
                self.mid_time.disable()
                self.rp_over_rs.disable()
                self.sma_over_rs.disable()
                self.eccentricity.disable()
                self.inclination.disable()
                self.periastron.disable()

        except Exception as e:
            if self.log.get_param('location') == '+dd:mm:ss +dd:mm:ss':
                self.showinfo('Test failed', 'Test failed! Please update the location of your telescope '
                                             'in the SELECT DATA & TARGET window.')
            elif self.auto_planet.get() == 'None':
                self.showinfo('Test failed', 'Test failed! Please update the target coordinates in the '
                                             'SELECT DATA & TARGET window or add the planet parameters manually.')
            else:
                self.showinfo('Test failed', 'Test failed! Please change the input parameters.'
                                             '\nMessage: {0}'.format(e))
            self.activate()
            self.fitting_button.disable()

    def run_fitting(self):

        fitting_directory = '.'.join(self.light_curve_file.get().split('.')[:-1]) + '_' + self.log.fitting_directory_base

        if not os.path.isdir(fitting_directory):
            os.mkdir(fitting_directory)
        else:
            fi = 2
            while os.path.isdir('{0}_{1}'.format(fitting_directory, str(fi))):
                fi += 1
            fitting_directory = '{0}_{1}'.format(fitting_directory, str(fi))
            os.mkdir(fitting_directory)

        try:
            planet, fitting = self.call_plc_fitting('emcee', fitting_directory)

            if fitting['mcmc_run_complete']:

                # saving

                shutil.copy(self.log.files['fitting_output_description'], fitting_directory)

                shutil.move(os.path.join(fitting_directory, 'global_correlations.pdf'),
                            os.path.join(fitting_directory, 'corner.pdf'))
                shutil.move(os.path.join(fitting_directory, 'global_traces.pdf'),
                            os.path.join(fitting_directory, 'traces.pdf'))
                shutil.move(os.path.join(fitting_directory, 'obs0_results.txt'),
                            os.path.join(fitting_directory, 'results.txt'))

                os.remove(os.path.join(fitting_directory, 'global_results.pickle'))
                os.remove(os.path.join(fitting_directory, 'global_results.txt'))
                os.remove(os.path.join(fitting_directory, 'obs0_results.pickle'))
                os.remove(os.path.join(fitting_directory, 'obs0_lightcurve.pdf'))

                np.savetxt(
                    os.path.join(fitting_directory, 'model.txt'),
                    np.swapaxes(
                        [
                            fitting['input_series']['time'],
                            (fitting['input_series']['time'] - fitting['parameters']['mid_time']['value'])/fitting['parameters']['period']['value'],
                            fitting['input_series']['flux'],
                            fitting['input_series']['flux_unc'],
                            fitting['output_series']['model'],
                            fitting['output_series']['residuals'],
                            ], 0, 1
                    )
                )

                np.savetxt(
                    os.path.join(fitting_directory, 'detrended_model.txt'),
                    np.swapaxes(
                        [
                            fitting['input_series']['time'],
                            (fitting['input_series']['time'] - fitting['parameters']['mid_time']['value'])/fitting['parameters']['period']['value'],
                            fitting['detrended_series']['flux'],
                            fitting['detrended_series']['flux_unc'],
                            fitting['detrended_series']['model'],
                            fitting['detrended_series']['residuals'],
                            ], 0, 1
                    )
                )

                funit = 0.8
                fcol = 7
                frow = 5
                fbottom = 0.11
                fright = 0.02
                fssmall = 8
                fsmain = 10
                fsbig = 20
                figure = Figure(figsize=(funit * fcol / (1 - fright), funit * frow / (1 - fbottom)))
                try:
                    gs = gridspec.GridSpec(frow, fcol, figure, 0.03, fbottom, 1.0 - fright, 1.0, 0.0, 0.0)
                except TypeError:
                    gs = gridspec.GridSpec(frow, fcol, 0.03, fbottom, 1.0 - fright, 1.0, 0.0, 0.0)

                logo_ax = figure.add_subplot(gs[0, 0])
                logo_ax.imshow(mpimg.imread(self.log.files['holomon_logo']))
                logo_ax.spines['top'].set_visible(False)
                logo_ax.spines['bottom'].set_visible(False)
                logo_ax.spines['left'].set_visible(False)
                logo_ax.spines['right'].set_visible(False)
                logo_ax.tick_params(left=False, bottom=False, labelleft=False, labelbottom=False)

                ax1 = figure.add_subplot(gs[1:4, 1:])
                ax2 = figure.add_subplot(gs[4, 1:])
                figure.text(0.04, fbottom + 2.5 * (1 - fbottom) / frow, 'Relative flux (norm)', fontsize=fsmain, va='center',
                            ha='center', rotation='vertical')
                figure.text(0.04, fbottom + 0.5 * (1 - fbottom) / frow, 'Residuals (norm)', fontsize=fsmain, va='center',
                            ha='center', rotation='vertical')

                title1 = figure.text(0.5, 0.94, '', fontsize=self.fsbig, va='center', ha='center')
                title2 = figure.text(0.97, 0.97, '', fontsize=self.fsmain, va='top', ha='right')
                title3 = figure.text(0.03 + (1 - fright) / fcol, 1 - (1 - fbottom) / frow, '', fontsize=self.fsmain, ha='left', va='bottom')

                self.plot_results_to_axes(planet, fitting, ax1, ax2, title1, title2, title3, 'De-trended')

                figure.savefig(os.path.join(fitting_directory, 'detrended_model.jpg'), dpi=1200, transparent=False)

                self.log.set_param('fitting_complete', True)
                self.log.set_param('fitting_version', self.log.version)

                self.log.save_local_log()

                self.log.export_local_log(fitting_directory)

                self.showinfo('Results saved successfully',
                              'Your results have been saved successfully in {0}'.format(fitting_directory))

        except:

            shutil.rmtree(fitting_directory)

            import traceback
            print(f'{traceback.format_exc()}')
            self.activate()

    def call_plc_fitting(self, optimiser, output_folder=None):

        if self.manual_planet.get():
            target_ra_dec_to_plot = self.target_ra_dec.get()
            metallicity_to_plot = self.metallicity.get()
            temperature_to_plot = self.temperature.get()
            logg_to_plot = self.logg.get()
            period_to_plot = self.period.get()
            mid_time_to_plot = self.mid_time.get()
            rp_over_rs_to_plot = self.rp_over_rs.get()
            sma_over_rs_to_plot = self.sma_over_rs.get()
            inclination_to_plot = self.inclination.get()
            eccentricity_to_plot = self.eccentricity.get()
            periastron_to_plot = self.periastron.get()

            planet_to_plot = self.planet.get()

        else:
            target_ra_dec_to_plot = self.auto_target_ra_dec.get()
            metallicity_to_plot = self.auto_metallicity.get()
            temperature_to_plot = self.auto_temperature.get()
            logg_to_plot = self.auto_logg.get()
            period_to_plot = self.auto_period.get()
            mid_time_to_plot = self.auto_mid_time.get()
            rp_over_rs_to_plot = self.auto_rp_over_rs.get()
            sma_over_rs_to_plot = self.auto_sma_over_rs.get()
            inclination_to_plot = self.auto_inclination.get()
            eccentricity_to_plot = self.auto_eccentricity.get()
            periastron_to_plot = self.auto_periastron.get()

            planet_to_plot = self.auto_planet.get()

        lc_full = self._load_lc_file_full()
        if lc_full is None:
            raise ValueError('Light curve file is missing or invalid.')
        active_lc, orig_map = self._active_lc_from_full(lc_full)
        if active_lc is None or active_lc.shape[1] < self._FITTING_LC_MIN_POINTS:
            raise ValueError('Too few points in the light curve after exclusions (min {0}).'.format(
                self._FITTING_LC_MIN_POINTS))
        self._orig_indices_active = orig_map
        light_curve = active_lc

        location_string = self.log.get_param('location').split(' ')
        observatory = exoclock.Observatory(exoclock.Degrees(location_string[0]), exoclock.Degrees(location_string[1]))

        ra_dec_string = target_ra_dec_to_plot.split(' ')
        planet = plc.Planet(
            planet_to_plot, exoclock.Hours(ra_dec_string[0]).deg(), exoclock.Degrees(ra_dec_string[1]).deg_coord(),
            logg_to_plot, temperature_to_plot, metallicity_to_plot,
            rp_over_rs_to_plot, period_to_plot, sma_over_rs_to_plot, eccentricity_to_plot, inclination_to_plot,
            periastron_to_plot, mid_time_to_plot)

        if self.detrending.get() == 'Airmass':
            detrending_series = 'airmass'
            detrending_order = 1
        elif self.detrending.get() == 'Linear':
            detrending_series = 'time'
            detrending_order = 1
        else:
            detrending_series = 'time'
            detrending_order = 2

        selected_filter = self.log.get_param('filter')
        requested_filter_name = filter_map[selected_filter]

        def _fit_with_filter(filter_name):
            planet.add_observation(
                time=light_curve[0, :],
                time_format='JD_UTC',
                exp_time=float(self.exposure_time),
                time_stamp='start',
                flux=light_curve[1, :],
                flux_unc=light_curve[2, :],
                flux_format='flux',
                filter_name=filter_name,
                observatory_latitude=observatory.latitude.deg_coord(),
                observatory_longitude=observatory.longitude.deg(),
                detrending_series=detrending_series,
                detrending_order=detrending_order
            )
            return planet.transit_fitting(
                output_folder=output_folder,
                scale_uncertainties=True, filter_outliers=True,
                fit_sma_over_rs=fit_sma_over_rs, fit_inclination=fit_inclination,
                counter=None, window_counter=True,
                iterations=self.iterations.get(), burn_in=self.burn.get(),
                optimiser=optimiser
            )

        if self.a_i_fit.get():
            fit_sma_over_rs = True
            fit_inclination = True
        else:
            fit_sma_over_rs = False
            fit_inclination = False

        try:
            return planet, _fit_with_filter(requested_filter_name)
        except Exception as e:
            if selected_filter in gaia_ld_fallback:
                fallback_filter_name = gaia_ld_fallback[selected_filter]
                self.log.runtime(
                    'Limb-darkening fallback for {0}: {1} -> {2} ({3})'.format(
                        selected_filter, requested_filter_name, fallback_filter_name, e
                    ),
                    level='WARNING'
                )
                planet = plc.Planet(
                    planet_to_plot, exoclock.Hours(ra_dec_string[0]).deg(), exoclock.Degrees(ra_dec_string[1]).deg_coord(),
                    logg_to_plot, temperature_to_plot, metallicity_to_plot,
                    rp_over_rs_to_plot, period_to_plot, sma_over_rs_to_plot, eccentricity_to_plot, inclination_to_plot,
                    periastron_to_plot, mid_time_to_plot)
                return planet, _fit_with_filter(fallback_filter_name)
            raise

    def plot_results_to_axes(self, planet, fitting_results, ax1, ax2, title1, title2, title3, lc_type):

        lc_full = self._load_lc_file_full()
        if lc_full is not None:
            active_head, _ = self._active_lc_from_full(lc_full)
        else:
            active_head = None
        if active_head is None or active_head.shape[1] < 1:
            light_curve = np.loadtxt(self.light_curve_file.get(), unpack=True)
            t0, t1 = light_curve[0][0], light_curve[0][-1]
        else:
            t0, t1 = active_head[0][0], active_head[0][-1]
        date = exoclock.Moment(jd_utc=t0).utc().isoformat()[:16].replace('T', ' ')
        obs_duration = round(24 * (t1 - t0), 1)

        title1.set_text(r'{0}{1}{2}'.format(r'$\mathbf{', planet.name, '}$'))

        title2.set_text('{0} (UT)\nDur: {1}h / Exp: {2}s\nFilter: {3}'.format(date, obs_duration, self.exposure_time,
                                                                                   self.log.get_param('filter')))
        title3.set_text(
            '\n\n{0}\n{1}'.format(
                self.log.get_param('observer'), '{0} / {1} / {2}'.format(
                    self.log.get_param('observatory'), self.log.get_param('telescope'), self.log.get_param('camera'))))

        ax1.cla()

        new_mid_time = fitting_results['parameters']['mid_time']['value']
        epoch = round((new_mid_time-planet.mid_time)/planet.period)
        predicted_mid_time = planet.mid_time + epoch * planet.period
        predicted_rp_over_rs = planet.rp_over_rs

        if lc_type == 'Raw':

            non_outliers = fitting_results['observations']['obs0']['data_conversion_info']['non_outliers_map']
            outliers = [ff for ff in np.arange(len(fitting_results['observations']['obs0']['original_data']['time']))
                        if ff not in non_outliers]

            time = fitting_results['observations']['obs0']['original_data']['time']
            flux = fitting_results['observations']['obs0']['original_data']['flux']
            flux_unc = fitting_results['observations']['obs0']['original_data']['flux_unc'] * fitting_results['observations']['obs0']['data_conversion_info']['scale_factor']

            best_fit_model_time = time[non_outliers]
            best_fit_model_flux = fitting_results['output_series']['model']

            predicted_model_time = time[non_outliers]
            predicted_model_flux = planet.transit_integrated(
                fitting_results['detrended_series']['time'],
                float(self.exposure_time), filter_map[self.log.get_param('filter')]
            ) * (best_fit_model_flux / fitting_results['detrended_series']['model'])

            std_res = fitting_results['statistics']['res_std']

            label = 'raw data'

            ax1.plot(
                time[outliers], flux[outliers], 'rx', ms=7, label='Outliers (not fitted)', zorder=1)
        else:

            time = fitting_results['detrended_series']['time']
            flux = fitting_results['detrended_series']['flux']
            flux_unc = fitting_results['detrended_series']['flux_unc']

            best_fit_model_time = time
            best_fit_model_flux = fitting_results['detrended_series']['model']

            predicted_model_time = fitting_results['detrended_series']['time']
            predicted_model_flux = planet.transit_integrated(
                fitting_results['detrended_series']['time'],
                float(self.exposure_time), filter_map[self.log.get_param('filter')]
            )

            std_res = fitting_results['detrended_statistics']['res_std']

            label = 'de-trended data'

        eb_main = ax1.errorbar(time, flux, flux_unc, c='k', fmt='o', ms=2, lw=0.5, label=label, zorder=0)

        data_ymin = min(flux) - 5 * std_res
        data_ymax = max(flux) + 2 * std_res

        ax1.set_yticks(ax1.get_yticks()[np.where(ax1.get_yticks() > data_ymin)])
        ymin, ymax = data_ymax - 1.1 * (data_ymax - data_ymin), data_ymax
        ax1.set_ylim(ymin, ymax)

        ax1.tick_params(labelbottom=False, labelsize=self.fsmain)

        ax1.plot(best_fit_model_time, best_fit_model_flux, 'r-',
                 label='Best-fit model (De-trending: {11}, a/Rs,i: {12})\n{0}{3}{0}={0}{4}_{1}-{5}{2}^{1}+{6}{2}{0}, '
                       '{0}{7}{0}={0}{8}_{1}-{9}{2}^{1}+{10}{2}{0}'.format(
                     '$', '{', '}',
                     fitting_results['parameters']['mid_time']['print_name'],
                     fitting_results['parameters']['mid_time']['print_value'],
                     fitting_results['parameters']['mid_time']['print_m_error'],
                     fitting_results['parameters']['mid_time']['print_p_error'],
                     fitting_results['parameters']['rp_over_rs']['print_name'],
                     fitting_results['parameters']['rp_over_rs']['print_value'],
                     fitting_results['parameters']['rp_over_rs']['print_m_error'],
                     fitting_results['parameters']['rp_over_rs']['print_p_error'],
                     self.detrending.get(),
                     ['Fixed', 'Free'][self.a_i_fit.get()],
                 ), zorder=3)

        ax1.plot(predicted_model_time, predicted_model_flux, 'c-',
                 label='Expected model\n{0}{3}{0}={0}{4}{0}, {0}{5}{0}={0}{6}{0}, '
                       'O-C={0}{7}_{1}-{8}{2}^{1}+{9}{2}{0} min'.format(
                     '$', '{', '}',
                     fitting_results['parameters']['mid_time']['print_name'],
                     round(predicted_mid_time, 5),
                     fitting_results['parameters']['rp_over_rs']['print_name'],
                     round(predicted_rp_over_rs, 5),
                     round((new_mid_time - predicted_mid_time) * 24 * 60, 1),
                     round(fitting_results['parameters']['mid_time']['m_error'] * 24 * 60, 1),
                     round(fitting_results['parameters']['mid_time']['p_error'] * 24 * 60, 1),
                 ), zorder=2)

        ax1.legend(loc=3, fontsize=self.fssmall)

        ax2.cla()

        detrended_flux_unc = fitting_results['detrended_series']['flux_unc']
        detrended_residuals = fitting_results['detrended_series']['residuals']
        detrended_std_res = fitting_results['detrended_statistics']['res_std']
        res_autocorr = fitting_results['statistics']['res_max_autocorr']
        res_autocorr_flag = fitting_results['statistics']['res_max_autocorr_flag']
        phase_res = (predicted_model_time - predicted_mid_time)/planet.period

        eb_res = ax2.errorbar(phase_res, detrended_residuals,  detrended_flux_unc, c='k', fmt='o', ms=2, lw=0.5)
        # ax2.plot(phase_res, detrended_residuals, 'ko', ms=2)
        ax2.plot(phase_res, np.zeros_like(phase_res), 'r-')

        ax2.set_ylim(- 6 * detrended_std_res, 6 * detrended_std_res)

        ax2.set_xlabel('Phase', fontsize=self.fsmain)

        ax2.tick_params(labelsize=self.fsmain)

        ax2.text(ax2.get_xlim()[0] + 0.02 * (ax2.get_xlim()[-1] - ax2.get_xlim()[0]),
                 ax2.get_ylim()[1] - 0.15 * (ax2.get_ylim()[-1] - ax2.get_ylim()[0]),
                 r'STD = %.2f $‰$' % (detrended_std_res * 1000),
                 fontsize=self.fssmall)
        ax2.text(ax2.get_xlim()[0] + 0.02 * (ax2.get_xlim()[-1] - ax2.get_xlim()[0]),
                 ax2.get_ylim()[0] + 0.07 * (ax2.get_ylim()[-1] - ax2.get_ylim()[0]),
                 r'AutoCorr = %.2f' %res_autocorr + [' (acceptable)', ' (too high)'][int(res_autocorr_flag)],
                 fontsize=self.fssmall)

        if self._orig_indices_active is not None and len(self._orig_indices_active) == len(time):
            self._pick_orig_index_map = np.asarray(self._orig_indices_active, dtype=int)
            self._register_pickable_errorbars(eb_main, eb_res)

    def show_point_info(self, event=None):
        if isinstance(event, mpl_MouseEvent):
            if event.inaxes and event.inaxes in (self.ax1, self.ax2) and event.button == 3:
                self._undo_last_point_exclusion()
                return
            if event.inaxes:
                if event.dblclick and not self.dblclick:
                    if event.y > 0.33 * self.preview_figure.canvas.get_tk_widget().winfo_reqheight():
                        idx = np.argmin((event.xdata - np.array([ff[1] for ff in self.science_files])) ** 2)
                        self.showinfo('Point information', self.science_files[idx][0])
                    self.dblclick = True
                else:
                    self.dblclick = False

    def save_settings(self):

        if self.manual_planet.get():
            planet_to_plot = self.planet.get()
            target_ra_dec_to_plot = self.target_ra_dec.get()
            metallicity_to_plot = self.metallicity.get()
            temperature_to_plot = self.temperature.get()
            logg_to_plot = self.logg.get()
            period_to_plot = self.period.get()
            mid_time_to_plot = self.mid_time.get()
            rp_over_rs_to_plot = self.rp_over_rs.get()
            sma_over_rs_to_plot = self.sma_over_rs.get()
            inclination_to_plot = self.inclination.get()
            eccentricity_to_plot = self.eccentricity.get()
            periastron_to_plot = self.periastron.get()
        else:
            planet_to_plot = self.auto_planet.get()
            target_ra_dec_to_plot = self.auto_target_ra_dec.get()
            metallicity_to_plot = self.auto_metallicity.get()
            temperature_to_plot = self.auto_temperature.get()
            logg_to_plot = self.auto_logg.get()
            period_to_plot = self.auto_period.get()
            mid_time_to_plot = self.auto_mid_time.get()
            rp_over_rs_to_plot = self.auto_rp_over_rs.get()
            sma_over_rs_to_plot = self.auto_sma_over_rs.get()
            inclination_to_plot = self.auto_inclination.get()
            eccentricity_to_plot = self.auto_eccentricity.get()
            periastron_to_plot = self.auto_periastron.get()

        self.log.set_param('light_curve_file', self.light_curve_file.get())
        self.log.set_param('iterations', self.iterations.get())
        self.log.set_param('burn', self.burn.get())
        self.log.set_param('a_i_fit', self.a_i_fit.get())
        self.log.set_param('detrending', self.detrending.get())
        self.log.set_param('manual_planet', self.manual_planet.get())
        self.log.set_param('planet', planet_to_plot)
        self.log.set_param('target_ra_dec', target_ra_dec_to_plot)
        self.log.set_param('metallicity', metallicity_to_plot)
        self.log.set_param('temperature', temperature_to_plot)
        self.log.set_param('logg', logg_to_plot)
        self.log.set_param('period', period_to_plot)
        self.log.set_param('mid_time', mid_time_to_plot)
        self.log.set_param('rp_over_rs', rp_over_rs_to_plot)
        self.log.set_param('sma_over_rs', sma_over_rs_to_plot)
        self.log.set_param('inclination', inclination_to_plot)
        self.log.set_param('eccentricity', eccentricity_to_plot)
        self.log.set_param('periastron', periastron_to_plot)
        self.log.set_param('aavso_detrended_model_file', self.export_window_aavso_detrended_path.get().strip())

        # save log

        self.log.save_local_log()

    def return_to_photometry(self):

        self.save_settings()
        self.log.set_param('proceed', 'return_to_photometry')
        self.close()

    def _aavso_sanitize_field(self, value):
        s = str(value).replace(',', ';').replace('\r', ' ').replace('\n', ' ').strip()
        return s

    def _photometry_source_directory(self):
        """Dossier PHOTOMETRY contenant le fichier courbe sélectionné (répertoire parent du .txt)."""
        lc = self.light_curve_file.get()
        if lc and lc != 'Choose Light-curve file' and os.path.isfile(lc):
            return os.path.dirname(os.path.abspath(lc))
        dir_param = self.log.get_param('directory')
        if dir_param and dir_param != 'Choose Directory' and os.path.isdir(dir_param):
            return dir_param
        return os.getcwd()

    def _split_star_and_exoplanet_name(self, planet_label):
        """Déduit STAR_NAME / EXOPLANET_NAME (ex. WASP-101 / WASP-101 b)."""
        s = (planet_label or '').strip() or 'UNKNOWN'
        if len(s) > 2 and s.endswith(' b'):
            star = s[:-2].strip()
            if star:
                return star, s
        if len(s) > 2 and s.endswith(' c'):
            star = s[:-2].strip()
            if star:
                return star, s
        return s, s

    def _browse_aavso_detrended(self):
        initialdir = None
        p = (self.export_window_aavso_detrended_path.get() or '').strip()
        if p and os.path.isfile(p):
            initialdir = os.path.dirname(os.path.abspath(p))
        else:
            d = self.log.get_param('directory')
            if d and d != 'Choose Directory' and os.path.isdir(d):
                initialdir = d
        try:
            cwd = os.getcwd()
        except Exception:
            cwd = None
        path = askopenfilename(
            parent=self.export_window.root,
            title='Select detrended_model.txt',
            filetypes=[('Text files', '*.txt'), ('All files', '*.*')],
            initialdir=initialdir if initialdir else (cwd or '.'),
        )
        if path:
            self.export_window_aavso_detrended_path.set(path)

    def _export_aavso(self, planet_to_plot):
        """
        Format EXOPLANET / Rnflux à partir du fichier detrended_model.txt choisi par l'utilisateur.
        Écrit HOPS_*_AAVSO_report.txt et fitting_output_description.txt dans le dossier PHOTOMETRY
        de la courbe sélectionnée.
        """
        obscode = self.export_window_aavso_obscode.get().strip()
        if not obscode:
            self.showinfo('AAVSO export', 'Please enter your AAVSO Observer ID (OBSCODE).')
            return

        det_path = (self.export_window_aavso_detrended_path.get() or '').strip()
        if not det_path or not os.path.isfile(det_path):
            self.showinfo(
                'AAVSO export',
                'Choose a valid detrended_model.txt file (Browse…).\n\n'
                'Expected layout: see fitting_output_description.txt (columns: BJD_TDB, phase, '
                'detrended flux, detrended uncertainty, …).',
            )
            return
        det_path = os.path.abspath(det_path)
        self.log.set_param('aavso_detrended_model_file', det_path)

        try:
            data = np.loadtxt(det_path)
        except Exception as e:
            self.showinfo('AAVSO export', 'Could not read detrended_model.txt:\n{0}'.format(e))
            return

        if data.ndim == 1:
            data = data.reshape(1, -1)
        if data.shape[1] < 4:
            self.showinfo('AAVSO export', 'detrended_model.txt must have at least 4 columns (time, phase, flux, uncertainty).')
            return

        time_bjd = np.asarray(data[:, 0], dtype=float)
        flux = np.asarray(data[:, 2], dtype=float)
        sig = np.asarray(data[:, 3], dtype=float)

        star_raw, exo_raw = self._split_star_and_exoplanet_name(planet_to_plot)
        star_name = self._aavso_sanitize_field(star_raw)
        exo_name = self._aavso_sanitize_field(exo_raw)

        report_base = 'HOPS_{4}_{0}_{1}_{2}_{3}s_AAVSO_report.txt'.format(
            self.observation_date[:10],
            planet_to_plot,
            self.log.get_param('filter'),
            self.exposure_time,
            self.light_curve_file.get().replace(os.sep, '_').replace('.txt', ''),
        )
        report_base = self._aavso_sanitize_field(report_base.replace(',', '_'))
        photometry_dir = self._photometry_source_directory()
        file_name = os.path.join(photometry_dir, report_base)

        try:
            bin_fits = int(self.log.get_param('bin_fits'))
        except Exception:
            bin_fits = 1
        if bin_fits < 1:
            bin_fits = 1
        binning_str = '{0}x{0}'.format(bin_fits)

        filt_raw = self.log.get_param('filter')
        filt_hdr = self._aavso_sanitize_field(filt_raw) if (filt_raw and str(filt_raw).strip()) else 'N/A'

        header_lines = [
            '#TYPE= EXOPLANET',
            '#OBSCODE={0}'.format(self._aavso_sanitize_field(obscode)),
            '#SOFTWARE=HOPS v{0}'.format(self.log.version),
            '#DELIM=,',
            '#DATE_TYPE=BJD-TDB',
            '#COLUMN_1=BJD-TDB',
            '#COLUMN_2=detrended-RnFlux',
            '#COLUMN_3=detrended-RnFlux_error',
            '#OBSTYPE=CCD',
            '#STAR_NAME={0}'.format(star_name),
            '#EXOPLANET_NAME={0}'.format(exo_name),
            '#BINNING={0}'.format(binning_str),
            '#EXPOSURE_TIME={0}'.format(int(round(float(self.exposure_time)))),
            '#FILTER={0}'.format(filt_hdr),
            '#DETREND_PARAMETERS=',
            '#MEASUREMENT_TYPE= Rnflux indicates relative normalized flux + Rnflux_error',
        ]

        desc_in_fit = os.path.join(os.path.dirname(det_path), 'fitting_output_description.txt')
        if os.path.isfile(desc_in_fit):
            desc_src = desc_in_fit
        else:
            desc_src = self.log.files['fitting_output_description']
        try:
            if os.path.isfile(desc_src):
                shutil.copy(desc_src, os.path.join(photometry_dir, 'fitting_output_description.txt'))
        except Exception:
            pass

        with open(file_name, 'w', encoding='utf-8', newline='') as w:
            w.write('\n'.join(header_lines) + '\n')
            n = len(time_bjd)
            for i in range(n):
                w.write('{0:.18e} , {1:.18e} , {2:.18e}\n'.format(time_bjd[i], flux[i], sig[i]))

        try:
            self.log.save_local_log()
        except Exception:
            pass

        self.showinfo(
            'Export',
            'EXOPLANET (Rnflux) saved in the photometry folder of the selected light curve:\n{0}\n\n'
            'fitting_output_description.txt copied to the same folder:\n{1}'.format(
                file_name, os.path.join(photometry_dir, 'fitting_output_description.txt')),
        )

    def export(self):

        if self.manual_planet.get():
            planet_to_plot = self.planet.get()
        else:
            planet_to_plot = self.auto_planet.get()

        if self._export_format == 'aavso':
            self._export_aavso(planet_to_plot)
            return

        light_curve = np.loadtxt(self.light_curve_file.get(), unpack=True)

        file_name = 'HOPS_{5}_{0}_{1}_{2}_{3}s_for_{4}.txt'.format(
            self.observation_date[:10],
            planet_to_plot,
            self.log.get_param('filter'),
            self.exposure_time,
            self.export_window_database.get(),
            self.light_curve_file.get().replace(os.sep, '_').replace('.txt', '')
        )

        w = open(file_name, 'w')

        w.write(self.export_window_header)

        for i in range(len(light_curve[0])):
            w.write('{0:.10f}\t{1:.10f}\t{2:.10f}\n'.format(light_curve[0][i] + self.export_window_time_shift,
                                             light_curve[1][i],
                                             light_curve[2][i] * (1 / np.sqrt(self.export_window_camera_gain.get())),
                                             ))

        self.showinfo('Export', 'File saved at: ' + file_name)

    def export_window_update(self):

        if self.manual_planet.get():
            planet_to_plot = self.planet.get()
        else:
            planet_to_plot = self.auto_planet.get()

        db = self.export_window_database.get()

        if db == 'ExoClock':

            self._export_format = 'exoclock'
            self.export_window_camera_gain.set(1.0)
            self.export_window_time_shift = 0
            self.export_window_aavso_detrended_path.disable()
            self.export_window_aavso_detrended_browse.disable()

            self.export_window_header = '\n'.join([
                '#Planet: {0}'.format(planet_to_plot),
                '#Time format: JD_UTC',
                '#Time stamp: Exposure start',
                '#Flux format: Flux',
                '#Filter: {0}'.format(self.log.get_param('filter')),
                '#Exposure time in seconds: {0}'.format(self.exposure_time),
                '#Time                   Flux            Flux uncertainty\n'
            ])

            self.export_window_message.set('No transformation is needed to upload your results to\nExoClock ' \
                                         '(www.exoclock.space).\n\nWhen uploading you will need to use the following ' \
                                         'details:\n' \
                                         'Planet: {0}\n'\
                                         'Time format: JD_UTC\n'\
                                         'Time stamp: Exposure start\n'\
                                         'Flux format: Flux\n'\
                                         'Filter: {1}\n'\
                                         'Exposure time in seconds: {2}'.format(planet_to_plot,
                                                                                self.log.get_param('filter'),
                                                                                self.exposure_time))

        elif db == 'ETD':

            self._export_format = 'etd'
            self.export_window_time_shift = self.exposure_time / 60 / 60 / 24 / 2
            self.export_window_aavso_detrended_path.disable()
            self.export_window_aavso_detrended_browse.disable()

            self.export_window_header = '\n'.join([
                '#Planet: {0}'.format(planet_to_plot),
                '#Time format: JD_UTC (geocentric)',
                '#Time stamp: Mid-exposure',
                '#Flux format: Flux (in flux)',
                '#Filter: {0}'.format(self.log.get_param('filter')),
                '#Exposure time in seconds: {0}'.format(self.exposure_time),
                '#Time                   Flux            Flux uncertainty\n'
            ])

            self.export_window_message.set('To upload your results to ETD (var2.astro.cz/ETD)\nthe following modifications ' \
                                         'are applied:\n\n' \
                                         '1. Half of the exposure time is added as the time-stamp required on ETD ' \
                                         'referes to the exposure mid-time\n' \
                                         '2. The uncertainties are  mupliplied by 1/SQRT(gain) to represent the ' \
                                         'uncertainies in electrons rather than counts.\n\n'\
                                         'When uploading you will need to use the following details:\n' \
                                         'Planet: {0}\n'\
                                         'JD format: geocentric\n'\
                                         'Brightness column: in flux'.format(planet_to_plot))

        else:

            self._export_format = 'aavso'

            self.export_window_header = ''
            self.export_window_aavso_detrended_path.activate()
            self.export_window_aavso_detrended_browse.activate()

            self.export_window_message.set(
                'EXOPLANET format / MEASUREMENT_TYPE Rnflux (no magnitudes).\n\n'
                'Select detrended_model.txt (Browse…). Columns used: BJD-TDB, detrended-RnFlux, '
                'detrended-RnFlux_error — see fitting_output_description.txt for the full 6-column '
                'definition of the source file.\n\n'
                'Export writes HOPS_*_AAVSO_report.txt and fitting_output_description.txt into the same '
                'PHOTOMETRY folder as the selected light-curve file (no mid-exposure offset or gain scaling).\n\n'
                'Enter your AAVSO OBSCODE. Verify submission rules on aavso.org before upload.'
            )
