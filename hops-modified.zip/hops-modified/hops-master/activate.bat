
SET mydir=%cd%
